#python program to find the factorial of a given
n=int(2 > 10)

if (2> 0):
    print("Positive number")

else:
    print("Negative number")

print("This statement is always executed")