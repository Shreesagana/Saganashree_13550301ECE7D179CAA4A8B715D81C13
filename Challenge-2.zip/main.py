#python program to find the factorial of a given
n=int("6")
fact=1
while(n>0):
  fact=fact*n
  n=n-1
print("factorial of the number is:")
print(fact)
